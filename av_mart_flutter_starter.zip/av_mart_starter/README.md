# AV-MART Flutter starter

This is the first UI starter for the AV-MART marketplace app. It includes a branded home screen, search field, 14 category tiles, and bottom navigation.

## Run it
1. Install Flutter SDK and Android Studio (or Xcode on macOS for iOS builds).
2. Create a Flutter project with `flutter create av_mart`.
3. Replace the generated `lib/main.dart` and `pubspec.yaml` with the files in this package.
4. Run `flutter pub get`.
5. Run `flutter run`.

## Important
This is a UI starter, not a complete shopping marketplace yet. Login/OTP, seller approval, product database, 5% commission calculations, payment gateway, delivery tracking, returns, admin dashboard, and translations still need backend services, credentials, testing, and integration. Never put payment secrets in the mobile app.
