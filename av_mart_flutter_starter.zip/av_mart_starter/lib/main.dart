import 'package:flutter/material.dart';

void main() => runApp(const AvMartApp());

class AvMartApp extends StatelessWidget {
  const AvMartApp({super.key});

  static const green = Color(0xFFB7E4A8);
  static const yellow = Color(0xFFFFD84D);
  static const blue = Color(0xFF2463A6);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AV-MART',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: blue),
        scaffoldBackgroundColor: const Color(0xFFF8FBF6),
        appBarTheme: const AppBarTheme(
          backgroundColor: green,
          foregroundColor: blue,
          centerTitle: false,
        ),
      ),
      home: const StoreHomePage(),
    );
  }
}

class StoreHomePage extends StatefulWidget {
  const StoreHomePage({super.key});

  @override
  State<StoreHomePage> createState() => _StoreHomePageState();
}

class _StoreHomePageState extends State<StoreHomePage> {
  int selectedTab = 0;
  final searchController = TextEditingController();

  static const categories = [
    ('Electronics', Icons.devices),
    ('Mobiles', Icons.phone_android),
    ("Men's Fashion", Icons.checkroom),
    ("Women's Fashion", Icons.woman),
    ('Kids & Baby', Icons.child_friendly),
    ('Home & Kitchen', Icons.kitchen),
    ('Grocery', Icons.local_grocery_store),
    ('Beauty', Icons.face_retouching_natural),
    ('Footwear', Icons.directions_run),
    ('Sports & Fitness', Icons.sports),
    ('Toys & Games', Icons.toys),
    ('Books & Stationery', Icons.menu_book),
    ('Furniture', Icons.chair),
    ('Automotive', Icons.directions_car),
  ];

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                color: AvMartApp.blue,
                borderRadius: BorderRadius.circular(12),
              ),
              alignment: Alignment.center,
              child: const Text('∧V', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 19)),
            ),
            const SizedBox(width: 10),
            const Text('AV-MART', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.1)),
          ],
        ),
        actions: [
          IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none)),
          IconButton(onPressed: () {}, icon: const Icon(Icons.person_outline)),
        ],
      ),
      body: IndexedStack(
        index: selectedTab,
        children: [
          _homeContent(),
          const _PlaceholderPage(icon: Icons.category_outlined, title: 'All Categories'),
          const _PlaceholderPage(icon: Icons.shopping_cart_outlined, title: 'Your Cart'),
          const _PlaceholderPage(icon: Icons.person_outline, title: 'My Account'),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: selectedTab,
        onDestinationSelected: (index) => setState(() => selectedTab = index),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.grid_view), label: 'Categories'),
          NavigationDestination(icon: Icon(Icons.shopping_cart_outlined), label: 'Cart'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'Account'),
        ],
      ),
    );
  }

  Widget _homeContent() {
    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
            child: TextField(
              controller: searchController,
              decoration: InputDecoration(
                hintText: 'Search products...',
                prefixIcon: const Icon(Icons.search),
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
              ),
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: Container(
            margin: const EdgeInsets.all(16),
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [AvMartApp.green, AvMartApp.yellow]),
              borderRadius: BorderRadius.circular(20),
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('WELCOME TO AV-MART', style: TextStyle(color: AvMartApp.blue, fontWeight: FontWeight.w900, fontSize: 19)),
                SizedBox(height: 6),
                Text('Shop smart. Find more. Save more.', style: TextStyle(color: AvMartApp.blue, fontSize: 14)),
                SizedBox(height: 14),
                Text('Discover products across 14 categories', style: TextStyle(color: AvMartApp.blue, fontWeight: FontWeight.w600)),
              ],
            ),
          ),
        ),
        const SliverToBoxAdapter(child: Padding(padding: EdgeInsets.fromLTRB(16, 4, 16, 12), child: Text('Shop by Category', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)))),
        SliverPadding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          sliver: SliverGrid(
            delegate: SliverChildBuilderDelegate(
              (context, index) {
                final item = categories[index];
                return Card(
                  elevation: 0,
                  color: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(16),
                    onTap: () {},
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        CircleAvatar(backgroundColor: AvMartApp.green, foregroundColor: AvMartApp.blue, child: Icon(item.$2)),
                        const SizedBox(height: 8),
                        Padding(padding: const EdgeInsets.symmetric(horizontal: 4), child: Text(item.$1, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600))),
                      ],
                    ),
                  ),
                );
              },
              childCount: categories.length,
            ),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, mainAxisSpacing: 8, crossAxisSpacing: 8, childAspectRatio: 0.95),
          ),
        ),
        const SliverToBoxAdapter(child: Padding(padding: EdgeInsets.all(20), child: Text('Products and seller listings will appear here after the catalogue and backend are connected.', textAlign: TextAlign.center, style: TextStyle(color: Colors.black54)))),
      ],
    );
  }
}

class _PlaceholderPage extends StatelessWidget {
  const _PlaceholderPage({required this.icon, required this.title});
  final IconData icon;
  final String title;

  @override
  Widget build(BuildContext context) => Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(icon, size: 54, color: AvMartApp.blue), const SizedBox(height: 12), Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)), const SizedBox(height: 6), const Text('This screen will be connected in the next development phase.')]),
      );
}
